The API notebooks are all executable! Hit "enter" in any code cell to execute it (and all cells before it that have not executed yet), or scroll to the bottom of the notebook and click "Play notebook". For more information, see [http://apinotebook.com](http://apinotebook.com).

#Considerations

- Please, refer to the [GitHub Notebooks collection](https://anypoint.mulesoft.com/apiplatform/popular/#/portals/apis/7782/versions/7918).
